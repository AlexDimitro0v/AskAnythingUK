/* filesys.c
 *
 * provides interface to virtual disk
 *
 */
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include "filesys.h"
#include <time.h>

diskblock_t  virtualDisk [MAXBLOCKS] ;           // define our in-memory virtual, with MAXBLOCKS blocks
fatentry_t   FAT         [MAXBLOCKS] ;           // define a file allocation table with MAXBLOCKS 16-bit entries
fatentry_t   rootDirIndex            = 0 ;       // rootDir will be set by format
direntry_t * currentDir              = NULL ;
fatentry_t   currentDirIndex         = 0 ;

/* writedisk : writes virtual disk out to physical disk
 *
 * in: file name of stored virtual disk
 */

void main() {
    format();
    writedisk("virtualdiskD3_D1");
    MyFILE *file;
    file = myfopen("testfile.txt","w");

    char str[4 * BLOCKSIZE];
    for (int i =0; i <  4 * BLOCKSIZE; i++)
    {
        str[i] = "ABCDEFGHIJKLMNOPQRSTUVWXWZ"[i % 26];
        myfputc(str[i],file);
    }
    myfclose(file);
    for (int i =0; i< MAXBLOCKS; i++) {
        printf("%d ", FAT[i]);
    }
    printf("\n");
    writedisk("virtualdiskC3_C1");

    mymkdir("/myfirstdir/myseconddir/mythirddir");

    char ** dirContents = mylistdir("/myfirstdir/myseconddir");
    for(int i =0; i < DIRENTRYCOUNT; i++)
    {
        printf("%s\n", dirContents[i]);
    }

    writedisk("virtualdiskB3_B1_a");

    mymkdir("/firstdir/seconddir");

    mylistdir("/firstdir/seconddir");
    mychdir("/firstdir/seconddir");
    mylistdir("/firstdir/seconddir");

    myfopen("testfile2.txt","w");
    char str2[200];
    for (int i =0; i < 200; i++)
    {
        str2[i] = 'A';
        myfputc(str2[i],file);
    }
    myfclose(file);

    mymkdir("thirddir");


    myrmdir("/firstdir/seconddir");

    myremove("/testfile.txt");
    writedisk("virtualdiskA5_A1");

}

void writedisk ( const char * filename )
{
    printf ( "writedisk> virtualdisk[0] = %s\n", virtualDisk[0].data ) ;
    FILE * dest = fopen( filename, "w" ) ;
    if ( fwrite ( virtualDisk, sizeof(virtualDisk), 1, dest ) < 0 )
        fprintf ( stderr, "write virtual disk to disk failed\n" ) ;
    //write( dest, virtualDisk, sizeof(virtualDisk) ) ;
    fclose(dest) ;

}

void readdisk ( const char * filename )
{
    FILE * dest = fopen( filename, "r" ) ;
    if ( fread ( virtualDisk, sizeof(virtualDisk), 1, dest ) < 0 )
        fprintf ( stderr, "write virtual disk to disk failed\n" ) ;
    //write( dest, virtualDisk, sizeof(virtualDisk) ) ;
    fclose(dest) ;
}


/* the basic interface to the virtual disk
 * this moves memory around
 */

void writeblock ( diskblock_t * block, int block_address )
{
    //printf ( "writeblock> block %d = %s\n", block_address, block->data ) ;
    memmove ( virtualDisk[block_address].data, block->data, BLOCKSIZE ) ;
    //printf ( "writeblock> virtualdisk[%d] = %s / %d\n", block_address, virtualDisk[block_address].data, (int)virtualDisk[block_address].data ) ;
}

void readblock ( diskblock_t * block, int block_address )
{
    memmove (block->data, virtualDisk[block_address].data, BLOCKSIZE ) ;
}


/* read and write FAT
 *
 * please note: a FAT entry is a short, this is a 16-bit word, or 2 bytes
 *              our blocksize for the virtual disk is 1024, therefore
 *              we can store 512 FAT entries in one block
 *
 *              how many disk blocks do we need to store the complete FAT:
 *              - our virtual disk has MAXBLOCKS blocks, which is currently 1024
 *                each block is 1024 bytes long
 *              - our FAT has MAXBLOCKS entries, which is currently 1024
 *                each FAT entry is a fatentry_t, which is currently 2 bytes
 *              - we need (MAXBLOCKS /(BLOCKSIZE / sizeof(fatentry_t))) blocks to store the
 *                FAT
 *              - each block can hold (BLOCKSIZE / sizeof(fatentry_t)) fat entries
 */

/* implement format()
 */
void format ( )
{
    diskblock_t block ;
    dirblock_t  rootDir ;
    int         pos             = 0 ;
    int         fatentry        = 0 ;
    int         fatblocksneeded =  (MAXBLOCKS / FATENTRYCOUNT ) ;

    /* prepare block 0 : fill it with '\0',
     * use strcpy() to copy some text to it for test purposes
     * write block 0 to virtual disk
     */
    for (int i =0; i < BLOCKSIZE ; i++) block.data[i] = '\0';

    strcpy(block.data,"CS3026 Assignment - Stepan Brychta");

    writeblock(&block, 0);

    /* prepare FAT table
     * write FAT blocks to virtual disk
     */
    for(int i = 0; i< MAXBLOCKS; i++) FAT[i] = UNUSED;

    FAT[0] = ENDOFCHAIN;
    for(int i = 0; i < fatblocksneeded -1; i++) {
        FAT[i+1] = i + 2;
    }
    FAT[fatblocksneeded] = ENDOFCHAIN;

    // FAT entry for root directory
    FAT[fatblocksneeded+1] = ENDOFCHAIN;

    copyFAT(fatblocksneeded);

    /* prepare root directory
     * write root directory block to virtual disk
     */
    memset(&rootDir, 0, sizeof(rootDir));

    rootDir.isdir = 1;
    rootDir.nextEntry = 0;

    diskblock_t rootDirBlock;
    memset(&rootDirBlock, 0, sizeof(rootDirBlock));
    rootDirBlock.dir = rootDir;


    writeblock(&rootDirBlock,fatblocksneeded+1);

    rootDirIndex = fatblocksneeded+1;
    currentDirIndex = rootDirIndex;
}

void copyFAT(int fatblocksneeded)
{
    diskblock_t block ;
    for(int i=0; i< fatblocksneeded; i++)
    {
        memmove ( &block,&FAT[BLOCKSIZE*i/2], BLOCKSIZE ) ;
        writeblock(&block,i+1);
    }
}

MyFILE * myfopen(const char * path, const char * mode)
{
    int dirEntryNum;
    int parentDirBlockNum = getDirBlockNumContainingEntry(path,&dirEntryNum,1);

    if (parentDirBlockNum!=-1)
    {
        // Read dir contents
        diskblock_t dirBlock;
        readblock(&dirBlock,parentDirBlockNum);

        // Look for the filename in the dir block
        fatentry_t fileFirstBlock = -1;
        if (dirEntryNum != -1) {
          fileFirstBlock = dirBlock.dir.entrylist[dirEntryNum].firstblock;
        }

        // Create a new file descriptor
        MyFILE * openedFileDescriptor = malloc(sizeof(MyFILE));
        strcpy(openedFileDescriptor -> mode ,mode);
        openedFileDescriptor -> pos = 0;

        if(fileFirstBlock != -1) {
            // Copy first block of file into file descriptor buffer
            readblock(&(openedFileDescriptor -> buffer),fileFirstBlock);
        }
        else {
            // Find the first free block
            int i;
            while (FAT[i] != UNUSED || i >= MAXBLOCKS) i++;

            // Disk full, cannot allocate block
            if (i >= MAXBLOCKS) return NULL;

            // Allocate the first free block to the newly created file
            FAT[i] = ENDOFCHAIN;

            direntry_t fileEntry;
            memset(&fileEntry, 0, sizeof(fileEntry));
            fileEntry.isdir = 0;
            fileEntry.unused = 0;
            fileEntry.filelength = 1;
            fileEntry.firstblock = i;
            strcpy(fileEntry.name,path);
            fileFirstBlock = i;
            dirBlock.dir.entrylist[dirBlock.dir.nextEntry++] = fileEntry;
            writeblock(&dirBlock,parentDirBlockNum);
        }

        openedFileDescriptor -> blockno = fileFirstBlock;
        return openedFileDescriptor;
    }
    else {
      // Path not valid
      return NULL;
    }
}

int myfgetc(MyFILE * stream)
{
    // End of current block
    if(stream -> pos >= BLOCKSIZE)
    {
        int nextBlock = FAT[stream -> blockno];
        if(nextBlock == ENDOFCHAIN) return EOF;

        readblock(&(stream -> buffer),nextBlock);

        stream -> blockno = nextBlock;
        stream -> pos = 0;
    }
    return stream -> buffer.data[stream -> pos];
}

void myfputc(int b, MyFILE *stream)
{
    if(stream -> pos >= BLOCKSIZE)
    {
        stream -> pos = 0;
        // First write current buffer to disk
        writeblock(&(stream -> buffer),stream -> blockno);

        int nextBlock = FAT[stream -> blockno];

        // Current file ends, need to allocate a new block
        if(nextBlock == ENDOFCHAIN) {
            int i = 0;
            while (FAT[i] != UNUSED || i >= MAXBLOCKS) i++;

            // Disk full, cannot allocate block
            if (i >= MAXBLOCKS) return;


            FAT[stream -> blockno] = i;
            FAT[i] = ENDOFCHAIN;
            nextBlock = i;
            stream -> blockno = nextBlock;
        }
        readblock(&(stream -> buffer),nextBlock);
    }

    stream -> buffer.data[stream -> pos] = b;
    stream -> pos = stream -> pos +1;
}

void myfclose(MyFILE * stream)
{
    // Write current buffer to disk
    writeblock(&(stream -> buffer),stream -> blockno);
    int fatblocksneeded = (MAXBLOCKS / FATENTRYCOUNT ) ;
    copyFAT(fatblocksneeded);
    free(stream);
}

void mymkdir(const char * path)
{
    diskblock_t baseDirBlock;
    loadBaseDirBlock(path,&baseDirBlock);
    diskblock_t * p;
    p = &baseDirBlock;

    // Determine whether path is absolute or relative
    int absolute = 0;
    if (path[0] == '/') absolute = 1;

    int prevDirBlockNum;
    if(absolute == 1) prevDirBlockNum = rootDirIndex;
    else prevDirBlockNum = currentDirIndex;

    char * token;
    char * rest = malloc(strlen(path) * sizeof(char));
    strcpy(rest,path);

    // Loop through all subdirectories and create them if they do not exist
    while ((token = strtok_r(rest, "/", &rest)))
    {
        int dirExists = 0;
        for(int i = 0; i < DIRENTRYCOUNT; i++)
        {
            if (strcmp(p -> dir.entrylist[i].name,token) == 0 && p -> dir.entrylist[i].isdir == 1)
            {
                dirExists = 1;
                diskblock_t currDirBlock;
                readblock(&currDirBlock,p -> dir.entrylist[i].firstblock);
                p = &currDirBlock;
                break;
            }
        }
        // If a directory in path does not exist, it must be created
        if (dirExists == 0)
        {
            diskblock_t newBlock;
            dirblock_t newDir;

            memset(&newBlock, 0, sizeof(newBlock));

            newDir.isdir = 1;
            newDir.nextEntry = 0;

            newBlock.dir = newDir;

            int i = 0;
            while (FAT[i] != UNUSED || i >= MAXBLOCKS) i++;

            // Disk full, cannot allocate block
            if (i >= MAXBLOCKS) return;

            FAT[i] = ENDOFCHAIN;

            direntry_t newDirEntry;
            newDirEntry.isdir = 1;
            newDirEntry.unused = 0;
            newDirEntry.filelength = 1;
            newDirEntry.modtime = time(0);
            newDirEntry.firstblock = i;
            strcpy(newDirEntry.name,token);
            p -> dir.entrylist[p -> dir.nextEntry++] = newDirEntry;

            // Write the previous directory into back into its block
            writeblock(p,prevDirBlockNum);

            prevDirBlockNum = i;
            p = &newBlock;
        }
    }
    free(rest);

    // Write updated FAT table to disk
    int fatblocksneeded = (MAXBLOCKS / FATENTRYCOUNT ) ;
    copyFAT(fatblocksneeded);
}

char ** mylistdir (const char * path)
{
    int dirEntryNum;
    int parentDirBlockNum = getDirBlockNumContainingEntry(path,&dirEntryNum,0);

    if (parentDirBlockNum!=-1)
    {
        diskblock_t blockContainingEntry;
        readblock(&blockContainingEntry,parentDirBlockNum);
        direntry_t * dirEntry = &(blockContainingEntry.dir.entrylist[dirEntryNum]);
        diskblock_t dirBlock;
        readblock(&dirBlock,dirEntry -> firstblock);

        char ** dirEntries = malloc(DIRENTRYCOUNT * sizeof(direntry_t *));
        for(int i =0; i< DIRENTRYCOUNT; i++) dirEntries[i] = dirBlock.dir.entrylist[i].name;
        return dirEntries;
    }
    // Path not valid
    return NULL;

}

void mychdir (const char * path)
{
    diskblock_t baseDirBlock;
    loadBaseDirBlock(path,&baseDirBlock);
    diskblock_t * p;
    p = &baseDirBlock;

    char * token;
    char * rest = malloc(strlen(path) * sizeof(char));
    strcpy(rest,path);

    int currDirEntryNum;
    diskblock_t prevDirBlock;

    int dirEntryNum;
    int parentDirBlockNum = getDirBlockNumContainingEntry(path,&dirEntryNum,0);

    if (parentDirBlockNum!=-1)
    {
        diskblock_t blockContainingEntry;
        readblock(&blockContainingEntry,parentDirBlockNum);
        direntry_t * dirEntry = &(blockContainingEntry.dir.entrylist[dirEntryNum]);
        currentDir = dirEntry;
        currentDirIndex = dirEntry -> firstblock;
    }

}

void myrmdir (const char * path)
{
    int removedDirEntryNum;
    int parentDirBlockNum = getDirBlockNumContainingEntry(path,&removedDirEntryNum,0);

    if (parentDirBlockNum!=-1)
    {
        diskblock_t blockContainingEntry;
        readblock(&blockContainingEntry, parentDirBlockNum);

        direntry_t * removedDirEntry = &(blockContainingEntry.dir.entrylist[removedDirEntryNum]);
        int removedFirstBlock = removedDirEntry -> firstblock;

        removedDirEntry -> unused = 1;
        removedDirEntry -> filelength = 0;
        removedDirEntry -> modtime = 0;
        removedDirEntry -> isdir = 0;
        removedDirEntry -> firstblock = 0;
        memset(removedDirEntry -> name,0,strlen(removedDirEntry -> name));

        // Wipe block containing dir
        diskblock_t block;
        memset(&block, 0, BLOCKSIZE);
        writeblock(&block,removedFirstBlock);

        if(blockContainingEntry.dir.nextEntry > removedDirEntryNum) {
          blockContainingEntry.dir.nextEntry = removedDirEntryNum;
        }

        // Write updated parent dir to disk
        writeblock(&blockContainingEntry,parentDirBlockNum);

        FAT[removedFirstBlock] = UNUSED;

        // Write updated FAT table to disk
        int fatblocksneeded = (MAXBLOCKS / FATENTRYCOUNT ) ;
        copyFAT(fatblocksneeded);
    }
}

void myremove(const char * path)
{
    int removedFileEntryNum;
    int parentDirBlockNum = getDirBlockNumContainingEntry(path,&removedFileEntryNum,0);

    if (parentDirBlockNum!=-1)
    {
        diskblock_t blockContainingEntry;
        readblock(&blockContainingEntry, parentDirBlockNum);
        direntry_t * removedFileEntry = &(blockContainingEntry.dir.entrylist[removedFileEntryNum]);

        removedFileEntry -> unused = 1;
        removedFileEntry -> filelength = 0;
        removedFileEntry -> modtime = 0;
        memset(removedFileEntry -> name,0,strlen(removedFileEntry -> name));

        // Wipe all blocks containing file
        diskblock_t block;
        memset(&block, 0, BLOCKSIZE);
        int i = removedFileEntry -> firstblock;
        int buffer;
        while(i != 0)
        {
            printf("%d\n", i);
            writeblock(&block,i);
            buffer = FAT[i];
            FAT[i] = UNUSED;
            i = buffer;
        }
        printf("%s",blockContainingEntry.dir.entrylist[0]);
        writeblock(&blockContainingEntry,parentDirBlockNum);

        // Write updated FAT table to disk
        int fatblocksneeded = (MAXBLOCKS / FATENTRYCOUNT ) ;
        copyFAT(fatblocksneeded);
    }
}

int getDirBlockNumContainingEntry(const char * path, int * dirEntryNum, Byte openingFile)
{
    diskblock_t baseDirBlock;
    int parentDirBlockNum = loadBaseDirBlock(path,&baseDirBlock);
    diskblock_t * p;
    p = &baseDirBlock;

    char * token;
    char * rest = malloc(strlen(path) * sizeof(char));
    strcpy(rest,path);

    // Loop through all subdirectories and check if path is valid
    while ((token = strtok_r(rest, "/", &rest)))
    {
        int dirExists = 0;
        *dirEntryNum = -1;
        for(int i = 0; i < DIRENTRYCOUNT; i++)
        {
            if (strcmp(p -> dir.entrylist[i].name,token) == 0)
            {
                dirExists = 1;
                *dirEntryNum = i;

                if(strcmp(rest, "")==0) {
                  free(rest);
                  return parentDirBlockNum;
                }

                parentDirBlockNum = p -> dir.entrylist[i].firstblock;
                readblock(p,p -> dir.entrylist[i].firstblock);

                break;
            }
        }
        // We are opening a file but it does not exits, return block of the folder where the file is to be created
        if(dirExists == 0 && strcmp(rest, "")==0 && openingFile == 1) return parentDirBlockNum;
        // Invalid path
        if (dirExists == 0) return -1;
    }
}


int loadBaseDirBlock(const char * path, diskblock_t * baseDirBlock)
{
    // Determine whether path is absolute or relative
    int absolute = 0;
    if (path[0] == '/') absolute = 1;

    // Read root dir contents
    if(absolute == 1) readblock(baseDirBlock,rootDirIndex);
        // Read current dir contents
    else readblock(baseDirBlock,currentDirIndex);

    if(absolute==1) return rootDirIndex;
    else return currentDirIndex;
}

/* use this for testing
 */

void printBlock ( int blockIndex )
{
    printf ( "virtualdisk[%d] = %s\n", blockIndex, virtualDisk[blockIndex].data ) ;
}
